package yaelomer.ballpuzzlegame2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import yaelomer.ballpuzzlegame2.model.User;

public class SignupActivity extends AppCompatActivity {

    EditText etUsername;
    EditText etPassword;

    Button btnSignup;

    TextView tvStatus;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnSignup = findViewById(R.id.btnSignup);
        tvStatus = findViewById(R.id.tvStatus);

        DbHelper dbHelper = new DbHelper(this);
        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etUsername.getText().toString().length() < 2)
                {
                    tvStatus.setTextColor(Color.RED);
                    tvStatus.setText("Username must be at least 2 characters!");
                    return;
                }

                if (etPassword.getText().toString().length() < 4)
                {
                    tvStatus.setTextColor(Color.RED);
                    tvStatus.setText("Password must be at least 4 characters!");
                }

                String username = etUsername.getText().toString().trim().toLowerCase();
                User user = new User(username,
                        etPassword.getText().toString(),0,0);
                dbHelper.addUser(user);
                tvStatus.setTextColor(Color.rgb(55, 145, 66));
                tvStatus.setText("Welcome!");
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(SignupActivity.this, OpenningActivity.class);
                        intent.putExtra("username", username);
                        startActivity(intent);
                    }
                }, 1500);

            }
        });


    }
}