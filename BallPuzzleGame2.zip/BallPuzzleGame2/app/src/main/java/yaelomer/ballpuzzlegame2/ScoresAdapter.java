package yaelomer.ballpuzzlegame2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import yaelomer.ballpuzzlegame2.model.User;

public class ScoresAdapter extends RecyclerView.Adapter<ScoresAdapter.ScoreViewHolder> {

    List<User> listUsers;

    public ScoresAdapter(List<User> listUsers)
    {
        this.listUsers = listUsers;
    }

    @NonNull
    @Override
    public ScoreViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(
                android.R.layout.simple_list_item_1, parent, false
        );
        return new ScoreViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ScoreViewHolder holder, int position) {
        User user = listUsers.get(position);
        holder.tvScore.setText(user.getUsername() + "  played games: " +
                user.getPlayedGames() + "  best score: " + user.getBestScore());
    }

    @Override
    public int getItemCount() {
        return listUsers.size();
    }

    static class ScoreViewHolder extends RecyclerView.ViewHolder {
        TextView tvScore;

        public ScoreViewHolder(@NonNull View itemView)
        {
            super(itemView);
            tvScore = itemView.findViewById(android.R.id.text1);
        }
    }
}
