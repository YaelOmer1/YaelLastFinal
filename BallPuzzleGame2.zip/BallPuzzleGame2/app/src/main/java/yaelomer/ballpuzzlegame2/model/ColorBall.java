package yaelomer.ballpuzzlegame2.model;

public enum ColorBall {
    LIGHTBLUE, PINK, PURPLE, YELLOW, RED, BLUE, GREEN, ORANGE, LIGHTPURPLE, LIGHTPINK;

}

