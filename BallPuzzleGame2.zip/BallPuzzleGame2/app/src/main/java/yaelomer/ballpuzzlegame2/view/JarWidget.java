package yaelomer.ballpuzzlegame2.view;

import android.graphics.Bitmap;

import yaelomer.ballpuzzlegame2.model.Ball;
import yaelomer.ballpuzzlegame2.model.Jar;

public class JarWidget extends Widget{

    private Jar jar;

    public JarWidget(Jar jar, int x, int y, Bitmap bitmap) {
        super(x,y, bitmap);
        this.jar = jar;
    }

    public Jar getJar() {
        return jar;
    }

}
