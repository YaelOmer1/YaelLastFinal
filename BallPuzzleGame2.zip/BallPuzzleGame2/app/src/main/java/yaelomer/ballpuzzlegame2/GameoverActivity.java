package yaelomer.ballpuzzlegame2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import yaelomer.ballpuzzlegame2.model.User;


public class GameoverActivity extends AppCompatActivity {

    RecyclerView rvScores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gameover);

        DbHelper dbHelper = new DbHelper(this);
        List<User> listUsers = dbHelper.getAllUsers();

//        listUsers.add(new User("Dan", "", 1, 1));
//        listUsers.add(new User("Gil", "", 1, 1));
//        listUsers.add(new User("Rinat", "", 1, 1));

        rvScores = findViewById(R.id.rvScores);
        rvScores.setLayoutManager(new LinearLayoutManager(this));
        ScoresAdapter adapter = new ScoresAdapter(listUsers);
        rvScores.setAdapter(adapter);

    }



}
