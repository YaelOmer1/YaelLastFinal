package yaelomer.ballpuzzlegame2;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import yaelomer.ballpuzzlegame2.model.User;

public class DbHelper extends SQLiteOpenHelper
{
    private static final String DB_NAME = "ball_puzzle.db";

    private static final int DB_VERSION = 2;

    public DbHelper(@Nullable Context context)
    {
        super(context, DB_NAME, null, DB_VERSION);
    }

    public void onCreate(SQLiteDatabase db)
    {
        String sql;

        sql = "CREATE TABLE IF NOT EXISTS users (" +
              "username TEXT PRIMARY KEY, " +
              "password TEXT," +
              "played_games," +
              "best_score INTEGER)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");

        onCreate(db);
    }

    public void addUser(User user)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "INSERT OR REPLACE INTO users " +
                     "(username, password, played_games, best_score) " +
                     "VALUES (?,?,?,?)";
        db.execSQL(sql, new Object[] {
                user.getUsername(),
                user.getPassword(),
                user.getPlayedGames(),
                user.getBestScore()
        });
    }

    public User getUser(String username)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT username, password, played_games, best_score " +
                "FROM users " +
                "WHERE username = ?";
        try (Cursor cursor = db.rawQuery(sql, new String[]{username})) {
            int countUsers = cursor.getCount();
            if (cursor.moveToFirst()) {
                // String username = cursor.getString(0);
                String password = cursor.getString(1);
                int playedGames = cursor.getInt(2);
                int bestScore = cursor.getInt(3);
                User user = new User(username, password, playedGames, bestScore);
                return user;
            }
        }

        return null;
    }

    public List<User> getAllUsers()
    {
        List<User> result = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT username, played_games, best_score " +
                "FROM users " +
                "ORDER BY username";
        try (Cursor cursor = db.rawQuery(sql, null)) {
            int countUsers = cursor.getCount();
            while (cursor.moveToNext()) {
                String username = cursor.getString(0);
                int playedGames = cursor.getInt(1);
                int bestScore = cursor.getInt(2);
                User user = new User(username, null, playedGames, bestScore);
                result.add(user);
            }
        }

        return result;
    }


    public void updateUser(User user)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "UPDATE users " +
                     "SET password=?, played_games=?, best_score=? " +
                     "WHERE username=?";
        db.execSQL(sql, new Object[] {
                user.getPassword(),
                user.getPlayedGames(),
                user.getBestScore(),
                user.getUsername()
        });
    }
}
