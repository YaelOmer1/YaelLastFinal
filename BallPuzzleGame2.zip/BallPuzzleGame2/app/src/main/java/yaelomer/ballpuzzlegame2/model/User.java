package yaelomer.ballpuzzlegame2.model;

public class User {
    private String username;
    private String password;
    private int playedGames;

    private int bestScore;

    public User(String username, String password, int playedGames, int bestScore) {
        this.username = username;
        this.password = password;
        this.playedGames = playedGames;
        this.bestScore = bestScore;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", playedGames=" + playedGames +
                ", bestScore=" + bestScore +
                '}';
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getPlayedGames() {
        return playedGames;
    }

    public void setPlayedGames(int playedGames) {
        this.playedGames = playedGames;
    }

    public int getBestScore() {
        return bestScore;
    }

    public void setBestScore(int bestScore) {
        this.bestScore = bestScore;
    }
}
