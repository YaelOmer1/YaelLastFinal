package yaelomer.ballpuzzlegame2;

import yaelomer.ballpuzzlegame2.model.Ball;
import yaelomer.ballpuzzlegame2.model.BallPuzzleGame;
import yaelomer.ballpuzzlegame2.model.Command;
import yaelomer.ballpuzzlegame2.model.Jar;
import yaelomer.ballpuzzlegame2.model.User;
import yaelomer.ballpuzzlegame2.view.BallWidget;
import yaelomer.ballpuzzlegame2.view.JarWidget;
import yaelomer.ballpuzzlegame2.view.MyCanvasView;

import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;

public class Controller {


    MainActivity mainActivity;

    String username;

    boolean backToStart = true;
    private Handler handler = new Handler(Looper.getMainLooper());


    // Handling ball dragging
    float startX, startY, endX, endY;
    boolean isMoving = false;

    private BallWidget selectedBallWidget;
    private JarWidget sourceJarWidget;

    private boolean gameWon = false;

    // Task for a thread to run the game replay
    private final Runnable replayRunnable = new Runnable() {
        @Override
        public void run() {
            canvasView.invalidate();

            if (backToStart)
            {
                if (ballPuzzleGame.getStackCommands().isEmpty())
                {
                    backToStart = false;
                }

                ballPuzzleGame.goBackOneMove();
                canvasView.invalidate();
            }
            else
            {
                if (ballPuzzleGame.getStackCommandsReversed().isEmpty())
                {
                    backToStart = true;
                    return;
                }

                ballPuzzleGame.goForwardOneMove();
                canvasView.invalidate();
            }

            handler.postDelayed(this, 1000);
        }
    };

    private BallPuzzleGame ballPuzzleGame;
    private MyCanvasView canvasView;

    public boolean isGameWon()
    {
        return gameWon;
    }

    public float getStartX() {
        return startX;
    }

    public float getStartY() {
        return startY;
    }

    public float getEndX() {
        return endX;
    }

    public float getEndY() {
        return endY;
    }

    public Controller(MainActivity activity, String username,
                      BallPuzzleGame game, MyCanvasView canvasView) {
        this.mainActivity = activity;
        this.username = username;
        this.ballPuzzleGame = game;
        this.canvasView = canvasView;
    }

    public void startGame(int level) {

        ballPuzzleGame.startGame(level);
    }

    public void goBackOneMove()
    {
        ballPuzzleGame.goBackOneMove();
        canvasView.invalidate();
    }



    public void replayBallMoves()
    {
        handler.postDelayed(replayRunnable, 1000);
    }

    public BallPuzzleGame getBallPuzzleGame()
    {
        return ballPuzzleGame;
    }

//    public boolean gameover() {
//        return ballPuzzleGame.gameOver();
//    }
    public boolean onTouchEvent(MotionEvent event)
    {
        switch (event.getAction())
        {
            case MotionEvent.ACTION_DOWN:

                if (selectedBallWidget != null)
                {
                    canvasView.canvasSuperOnTouchEvent(event);
                }

                startX = endX = event.getX();
                startY = endY = event.getY();
                for (JarWidget jarWidget: canvasView.getListJarWidgets())
                {
                    if (jarWidget.isCollideWithPoint((int)startX, (int)startY))
                    {
                        Ball ball = jarWidget.getJar().removeBall();
                        selectedBallWidget = canvasView.getMapBallToBallWidgets().get(ball);
                        sourceJarWidget = jarWidget;
                    }
                }
                isMoving = true;
                canvasView.invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                endX = event.getX();
                endY = event.getY();
                canvasView.invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                if (selectedBallWidget == null)
                {
                    return canvasView.canvasSuperOnTouchEvent(event);
                }

                endX = event.getX();
                endY = event.getY();
                isMoving = false;

                Ball ball = selectedBallWidget.getBall();
                boolean wasBallDroppedInJar = false;
                for (JarWidget jarWidget: canvasView.getListJarWidgets())
                {
                    // Check if finger touched one of the jars
                    if (jarWidget.isCollideWithPoint((int)endX, (int)endY))
                    {
                        wasBallDroppedInJar = true;
                        if (jarWidget.getJar().getBallsStack().isEmpty())
                        {
                            jarWidget.getJar().addBall(ball);
                            getBallPuzzleGame().increaseStepsCount();
                            getBallPuzzleGame().
                                    getStackCommands().push(
                                            new Command(sourceJarWidget.getJar(),
                                                    jarWidget.getJar()));
                        }
                        else if (jarWidget.getJar().getBallsStack().size() >= Jar.MAX_BALLS_IN_JAR ||
                                jarWidget.getJar().getBallsStack().peek().getColor() !=
                                        selectedBallWidget.getBall().getColor())
                        {
                            sourceJarWidget.getJar().addBall(ball);
                        }
                        else
                        {
                            jarWidget.getJar().addBall(ball);
                            getBallPuzzleGame().increaseStepsCount();
                            getBallPuzzleGame().
                                    getStackCommands().push(
                                            new Command(sourceJarWidget.getJar(),
                                                    jarWidget.getJar()));

                            if (jarWidget.getJar().getBallsStack().size() == Jar.MAX_BALLS_IN_JAR)
                            {
                                if (getBallPuzzleGame().isWin())
                                {
                                    this.gameWon = true;
                                    int scoreFromDb = getUserScoreFromDb(username);
                                    int currentScore =
                                            getBallPuzzleGame().getLevel()*100 -
                                            getBallPuzzleGame().getStepsCount();
                                    int scoreToSave = Math.max(scoreFromDb, currentScore);
                                    updateWonGameInDb(username, scoreToSave);
                                    new Handler(Looper.getMainLooper()).post(()->{
                                       mainActivity.displayButtonSeeScores();
                                    });
                                }
                            }
                        }
                    }
                }

                if (!wasBallDroppedInJar)
                {
                    sourceJarWidget.getJar().addBall(ball);
                }

                selectedBallWidget = null;
                canvasView.invalidate();
        }
        return canvasView.canvasSuperOnTouchEvent(event);

    }

    private void updateWonGameInDb(String username, int score)
    {
        DbHelper dbHelper = new DbHelper(mainActivity);
        User user =  dbHelper.getUser(username);
        if (user == null)
        {
            return;
        }
        dbHelper.updateUser(new User(username, user.getPassword(), user.getPlayedGames()+1,
                score));

    }

    private int getUserScoreFromDb(String username)
    {
        DbHelper dbHelper = new DbHelper(mainActivity);
        User user =  dbHelper.getUser(username);
        if (user == null)
        {
            return 0;
        }
        return user.getBestScore();
    }

    public BallWidget getSelectedBallWidget() {
        return selectedBallWidget;
    }
}
